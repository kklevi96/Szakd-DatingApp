﻿namespace DatingApp.Dtos.Meetings
{
    public class UpdateMeetingRequest
    {
        public int LocationId { get; set; }
        public DateTime MeetingDate { get; set; }
    }
}
